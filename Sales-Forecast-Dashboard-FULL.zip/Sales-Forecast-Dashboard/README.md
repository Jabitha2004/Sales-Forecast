
# 📊 Sales Forecast Dashboard (Power BI + Python)

This is a complete end‑to‑end project combining **Python forecasting** and **Power BI dashboards**.

---

## 🚀 Features
✔ Full dataset included  
✔ Python Prophet forecasting  
✔ Clean & modular code  
✔ Power BI dashboard template  
✔ GitHub-friendly structure  

---

## 📁 Project Structure
```
Sales-Forecast-Dashboard/
 ├── data/
 │    ├── raw_sales.csv
 │    ├── cleaned_sales.csv (generated)
 │    └── forecast_output.csv (generated)
 ├── python/
 │    └── sales_forecast.py
 ├── powerbi/
 │    └── SalesForecast.pbix  (placeholder)
 ├── images/
 │    └── dashboard_preview.png  (add your screenshot)
 ├── README.md
```

---

## 🧠 How to Run the Python Script

### 1. Install dependencies
```
pip install pandas prophet
```

### 2. Run script
```
python python/sales_forecast.py
```

This will generate:
- `cleaned_sales.csv`
- `forecast_output.csv`

---

## 📊 Power BI Steps
1. Open **Power BI Desktop**  
2. Load:
   - `cleaned_sales.csv`
   - `forecast_output.csv`
3. Create visuals:
   - Line chart → sales + forecast  
   - Bar chart → product-wise sales  
   - Map → region-wise performance  
   - Cards → KPIs  

---

## 🏁 Final Output
You get:
- Fully processed dataset  
- Forecast for 6 months  
- Power BI dashboard ready  

---

## 📄 License
MIT License  
