
import pandas as pd
from prophet import Prophet

print("Loading data...")
df = pd.read_csv("../data/raw_sales.csv")

df['Date'] = pd.to_datetime(df['Date'])
df = df.sort_values("Date")

df = df[df['Sales'] > 0].dropna()

df.to_csv("../data/cleaned_sales.csv", index=False)
print("Cleaned data saved.")

sales_daily = df.groupby("Date")["Sales"].sum().reset_index()
sales_daily.columns = ["ds", "y"]

print("Training Prophet model...")
model = Prophet()
model.fit(sales_daily)

future = model.make_future_dataframe(periods=180)
forecast = model.predict(future)

forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].to_csv(
    "../data/forecast_output.csv",
    index=False
)

print("Forecast saved to forecast_output.csv")
